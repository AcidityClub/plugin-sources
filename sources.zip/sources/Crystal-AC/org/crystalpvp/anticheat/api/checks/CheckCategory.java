package org.crystalpvp.anticheat.api.checks;

/**
 *  Coded by 4Remi#8652
 *   DO NOT REMOVE
 */

public enum CheckCategory {
    COMBAT,
    MOVEMENT,
    OTHER,
    DEBUG
}
