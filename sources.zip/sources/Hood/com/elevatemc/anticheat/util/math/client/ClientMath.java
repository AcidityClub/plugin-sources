package com.elevatemc.anticheat.util.math.client;

public interface ClientMath {
    float sin(float value);

    float cos(float value);
}