package me.frep.vulcan.spigot.id;

public class ID
{
    public static String spigot() {
        return "HALAL 5170 EDITION";
    }
    
    public static String nonce() {
        return "LICENSED TO: NIGGAS FROM THE HOOD";
    }
    
    public static String resource() {
        return "%%__RESOURCE__%%";
    }
}
