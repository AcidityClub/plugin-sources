package fr.body.ectasy.util;

public class Vars {
   public static String CURRENT_DIR = System.getProperty("user.dir");
}
