package me.vagdedes.spartan.checks.combat.a.a;

import me.vagdedes.spartan.checks.combat.a.c.a.CAEventListeners;

public class CAQueue
{
    private CAEventListeners.b a;
    private CAEventListeners.a a;
    private double value;
    
    public CAQueue(final CAEventListeners.b a, final CAEventListeners.a a2, final double value) {
        super();
        this.a = a;
        this.a = a2;
        this.value = value;
    }
    
    public CAEventListeners.b a() {
        return this.a;
    }
    
    public CAEventListeners.a a() {
        return this.a;
    }
    
    public double getValue() {
        return this.value;
    }
}
